import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  product: any;
  products = [];
  state: Boolean;

  constructor(private _httpService: HttpService,
    private _route: ActivatedRoute,
      private _router: Router) { }

  ngOnInit(){
    this._route.params.subscribe((params: Params) => {
    let id = (params['id']);
    console.log("is this working",params['id']);
    console.log("or is this the id", params.id);
    let observable = this._httpService.findOne(params.id);
    observable.subscribe((data:any) =>{
      console.log(data);
      console.log(data.product);
      this.product = data.product[0];
      console.log(this.product);
      console.log("do we get the quantity", data.product[0].quantity);
      if(data.product[0].quantity > 0){
        this.state = true;
        console.log(this.state);
      } else if (data.product[0].quantity = 0) {
        this.state = false;
      }

    });
  });
}

onButtonClickDelete(event:any){
  let observable = this._httpService.deleteProduct(event);
  console.log(event);
  observable.subscribe((data:any) => {
      // const tasks = data.json();
      console.log("what is this data", data)
      // this.deleteTask =
      console.log("we just want to delete the product", event);

   });

}



}
