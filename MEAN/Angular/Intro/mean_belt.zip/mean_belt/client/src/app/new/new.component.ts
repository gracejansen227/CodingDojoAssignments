import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  product: any;
  products = [];
  name_error: any;
  price_error: any;
  quantity_error: any;
  state: boolean;

  constructor(private _httpService: HttpService,   private _route: ActivatedRoute,
      private _router: Router) { }

  ngOnInit() {
    this.product = {name: "", price: "", quantity: ""};
  }

onSubmitNew(event){
  event.preventDefault();
  this.name_error= null;
  this.price_error= null;
  this.quantity_error = null;
  let observable = this._httpService.addProduct(this.product);
  observable.subscribe((data:any) => {
    // const tasks = data.json();
    console.log("This should be adding our new stuff!", data)
    // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
    // This may be different for you, depending on how you set up your Task API.

    this.product = {name: data.data.name, price: data.data.price, quantity: data.data.quantity}
    console.log( "this is the info this.newTask", this.product);
      this._router.navigate([`/table`]);
      this.state = true;
 },
(err: any) => {
  console.log(err);
if (err.error.errors.name){
  this.name_error = err.error.errors.name.message;
  this.state = false;
}

if (err.error.errors.price){
  this.price_error = err.error.errors.price.message;
  this.state = false;
}

if (err.error.errors.quantity){
  this.quantity_error = err.error.errors.quantity.message;
  this.state = false;
}
});

}

}
