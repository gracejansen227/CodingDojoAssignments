import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-new',
  templateUrl: './new.component.html',
  styleUrls: ['./new.component.css']
})
export class NewComponent implements OnInit {
  pet: any;
  pets = [];
  name_error: any;
  type_error: any;
  description_error: any;

  constructor(private _httpService: HttpService,   private _route: ActivatedRoute,
      private _router: Router) { }

  ngOnInit() {
    this.pet = {name: "", type: "", description: "", skill1: "", skill2: "", skill3: "", likes: 0};
  }

onSubmitNew(event){
  event.preventDefault();
  this.name_error= null;
  this.type_error= null;
  this.description_error = null;
  let observable = this._httpService.addPet(this.pet);
  observable.subscribe((data:any) => {
    // const tasks = data.json();
    console.log("This should be adding our new stuff!", data)
    // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
    // This may be different for you, depending on how you set up your Task API.
    console.log(this.pet);

    console.log(data.data.skill1);
    this.pet = {name: data.data.name, type: data.data.type, description: data.data.description,
      skill1: data.data.skill1, skill2: data.data.skill2, skill3: data.data.skill3, likes: 0
    }
    console.log( "this is the info this.newTask", this.pet);
      this._router.navigate([`/table`]);

 },
(err: any) => {
  console.log("this is the whole error",err);
if (err.error.errors.name){
  this.name_error = err.error.errors.name.message;
}

if (err.error.errors.type){
  this.type_error = err.error.errors.type.message;
}

if (err.error.errors.description){
  this.description_error = err.error.errors.description.message;

}
});

}

}
