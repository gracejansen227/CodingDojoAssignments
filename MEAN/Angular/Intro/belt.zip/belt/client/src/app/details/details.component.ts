import { Component, OnInit } from '@angular/core';
import { HttpService } from 'app/http.service';
import { ActivatedRoute, Params, Router } from '@angular/router';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.css']
})
export class DetailsComponent implements OnInit {
  pet: any;
  pets = [];
  likes: any;
  disableLike: boolean;

  constructor(private _httpService: HttpService,
    private _route: ActivatedRoute,
      private _router: Router) { }

  ngOnInit(){
    this.disableLike = false;
    this._route.params.subscribe((params: Params) => {
    let id = (params['id']);
    console.log("is this working",params['id']);
    console.log("or is this the id", params.id);
    let observable = this._httpService.findOne(params.id);
    observable.subscribe((data:any) =>{
      console.log(data);
      console.log(data.pet);
      this.pet = data.pet[0];
      console.log(this.pet);

    });
  });
}


updateThis(){
  this._route.params.subscribe((params: Params) => {
  let id = (params['id']);
  console.log("is this working",params['id']);
  console.log("or is this the id", params.id);
  let observable = this._httpService.findOne(params.id);
  observable.subscribe((data:any) =>{
    console.log(data);
    console.log(data.pet);
    this.pet = data.pet[0];
    console.log(this.pet);

  });
});
}

onButtonClickDelete(event:any){
  let observable = this._httpService.deletePet(event);
  console.log(event);
  observable.subscribe((data:any) => {
      // const tasks = data.json();
      console.log("what is this data", data)
      // this.deleteTask =
      console.log("we just want to delete the pet", event);
        this._router.navigate([`/table`]);

   });

}

addLike(id){
  let observable = this._httpService.like(id);
  observable.subscribe((data:any) => {
    console.log("this should be updated likes right?", data);
    this.likes = data.pet.likes;
    console.log(this.likes);
    this.disableLike = true;
    console.log(this.disableLike);
    this.updateThis();

  });
}



}
