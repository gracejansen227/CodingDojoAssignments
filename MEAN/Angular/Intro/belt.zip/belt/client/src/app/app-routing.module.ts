import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewComponent} from './new/new.component';
import { EditComponent} from './edit/edit.component';
import { AppComponent} from './app.component';
import {TableComponent} from './table/table.component';
import {DetailsComponent} from './details/details.component';

const routes: Routes = [
  { path: 'new', component: NewComponent},
  { path: 'edit/:id', component: EditComponent},
  { path: 'table', component: TableComponent},
   { path: '', pathMatch: 'full',component: TableComponent},
   { path: 'pets/:id', component: DetailsComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
