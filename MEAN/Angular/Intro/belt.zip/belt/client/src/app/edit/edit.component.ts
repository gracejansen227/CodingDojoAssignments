import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpService } from 'app/http.service';

@Component({
  selector: 'app-edit',
  templateUrl: './edit.component.html',
  styleUrls: ['./edit.component.css']
})
export class EditComponent implements OnInit {
  pet: any;
  pets= [];
  name_error: any;
  type_error: any;
  description_error: any;

  constructor(private _httpService: HttpService,
    private _route: ActivatedRoute,
      private _router: Router) { }

  ngOnInit(){
    //right here is where i need to add the funcitonality to reset it to original values!
    this.pet= {_id: "", name: "", type: 0, description: 0};
    this._route.params.subscribe((params: Params) => {
      //console.log("this isjust params",params);
    //let id = (params['id']);
    //this.author = {_id: params['id']};
    console.log("is this working",params['id']);
    let observable = this._httpService.findOne(params['id']);
    observable.subscribe((data:any) => {
        // const tasks = data.json();
        console.log("Got our pet!", data)
        // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
        // This may be different for you, depending on how you set up your Task API.
        console.log(data.pet);
        console.log("what is this shit here", data.pet[0]);
         this.pet = data.pet[0];


  });
});
}

onEditPet(event:any){
  event.preventDefault();
  this.name_error= null;
  this.type_error= null;
  this.description_error= null;
  this._route.params.subscribe((params: Params) => {

let observable = this._httpService.editPet(params['id'],{name: this.pet.name, type: this.pet.type, description: this.pet.description, skill1: this.pet.skill1, skill2: this.pet.skill2, skill3: this.pet.skill3});

observable.subscribe((data: any) => {
  //this.getAuthorsFromService();
   console.log(data);
    console.log("we just want to edit the task");
this.pet= {_id: "", name: "", type: "", description:"", skill1: "", skill2: "", skill3: ""};
  this._router.navigate([`/table`]);
},
(err: any) => {
  console.log(err);
  if(err.error.errors.name){
  this.name_error = err.error.errors.name.message;


  }

if (err.error.errors.type){
  this.type_error = err.error.errors.type.message;

}

if (err.error.errors.description){
  this.description_error = err.error.errors.description.message;
}
});
});

}

resetpage(){
  this.pet= {_id: "", name: "", type: "", description:"", skill1: "", skill2:"", skill3:""};
  this._route.params.subscribe((params: Params) => {
    //console.log("this isjust params",params);
  //let id = (params['id']);
  //this.author = {_id: params['id']};
  console.log("is this working",params['id']);
  let observable = this._httpService.findOne(params['id']);
  observable.subscribe((data:any) => {
      // const tasks = data.json();
      console.log("Got our pet!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
      // This may be different for you, depending on how you set up your Task API.
      console.log(data.pet);
      console.log("what is this shit here", data.pet[0]);
       this.pet = data.pet[0];


     });
   });
   }


getPetsFromService(){
  let observable = this._httpService.getAllPets();
  observable.subscribe((data:any) => {
      // const tasks = data.json();
      console.log("Got our pets!", data)
      // In this example, the array of tasks is assigned to the key 'tasks' in the data object.
      // This may be different for you, depending on how you set up your Task API.
      console.log(data.data);
       this.pets = data.data;

   });

}

}
